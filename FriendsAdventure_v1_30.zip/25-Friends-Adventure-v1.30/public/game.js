const socket=io();
const animalData=[["Kelinci","🐰"],["Kucing","🐱"],["Panda","🐼"],["Beruang","🐻"],["Anak Ayam","🐥"],["Gajah","🐘"],["Rubah","🦊"],["Katak","🐸"],["Singa","🦁"],["Harimau","🐯"],["Monyet","🐵"],["Koala","🐨"],["Anjing","🐶"],["Penguin","🐧"],["Jerapah","🦒"],["Kura-kura","🐢"],["Burung Hantu","🦉"],["Babi","🐷"],["Rusa","🦌"],["Unicorn","🦄"],["Tupai","🐿️"],["Serigala","🐺"],["Kuda","🐴"],["Domba","🐑"],["Bebek","🦆"]];
const categories=[["buah","Buah","🍎"],["sayuran","Sayuran","🥕"],["tanaman","Tanaman","🌻"],["alat-tulis","Alat tulis","✏️"]];
const playerBadgeColors = [
  ["#E53935","#FFFFFF"],["#1E88E5","#FFFFFF"],["#43A047","#FFFFFF"],["#8E24AA","#FFFFFF"],["#FB8C00","#202020"],
  ["#00897B","#FFFFFF"],["#D81B60","#FFFFFF"],["#6D4C41","#FFFFFF"],["#3949AB","#FFFFFF"],["#7CB342","#202020"],
  ["#F4511E","#FFFFFF"],["#00ACC1","#202020"],["#5E35B1","#FFFFFF"],["#C0CA33","#202020"],["#546E7A","#FFFFFF"],
  ["#EC407A","#202020"],["#26A69A","#202020"],["#AB47BC","#FFFFFF"],["#FFA726","#202020"],["#78909C","#FFFFFF"],
  ["#EF5350","#FFFFFF"],["#42A5F5","#202020"],["#66BB6A","#202020"],["#FFCA28","#202020"],["#7E57C2","#FFFFFF"]
];
function getPlayerBadgeStyle(number){
  const pair=playerBadgeColors[(Math.max(1,Number(number)||1)-1)%playerBadgeColors.length];
  return {backgroundColor:pair[0],color:pair[1]};
}
let selectedNumber=null, selectedAnimal=null, currentState=null, joined=false, joinPending=false, game=null, sceneRef=null;
let previousPlayerTotals=new Map();
let quizOpen=false;
let quizAnswerTimer=null;
let quizAnswerPending=false;
const virtualInput={up:false,down:false,left:false,right:false};
let soundContext=null;
const $=id=>document.getElementById(id);
function playBeep(kind="tap"){
 try{
   const AudioCtx=window.AudioContext||window.webkitAudioContext;
   if(!AudioCtx)return;
   if(!soundContext)soundContext=new AudioCtx();
   if(soundContext.state==="suspended")soundContext.resume();
   const now=soundContext.currentTime;
   const notes=kind==="correct"?[660,880]:kind==="wrong"?[220]:kind==="question"?[520]:[440];
   notes.forEach((freq,index)=>{
     const osc=soundContext.createOscillator();
     const gain=soundContext.createGain();
     osc.type="sine";osc.frequency.setValueAtTime(freq,now+index*.12);
     gain.gain.setValueAtTime(.0001,now+index*.12);
     gain.gain.exponentialRampToValueAtTime(.12,now+index*.12+.015);
     gain.gain.exponentialRampToValueAtTime(.0001,now+index*.12+.13);
     osc.connect(gain);gain.connect(soundContext.destination);
     osc.start(now+index*.12);osc.stop(now+index*.12+.14);
   });
 }catch(e){}
}
function requestGameFullscreen(){
 const target=document.documentElement;
 if(document.fullscreenElement)return Promise.resolve(true);
 if(target.requestFullscreen)return target.requestFullscreen({navigationUI:"hide"}).then(()=>true).catch(()=>false);
 // iOS Safari only supports fullscreen on certain media elements; keep the game usable.
 return Promise.resolve(false);
}
function sendVirtualInput(){
 if(!joined||quizOpen)return;
 socket.emit("input",{...virtualInput});
}
function bindVirtualJoystick(){
 document.querySelectorAll(".joy-key[data-direction]").forEach(button=>{
   const direction=button.dataset.direction;
   const down=e=>{
     e.preventDefault();playBeep("tap");
     virtualInput[direction]=true;button.classList.add("pressed");
     try{button.setPointerCapture(e.pointerId);}catch(err){}
     sendVirtualInput();
   };
   const up=e=>{
     e.preventDefault();virtualInput[direction]=false;button.classList.remove("pressed");
     sendVirtualInput();
   };
   button.addEventListener("pointerdown",down);
   ["pointerup","pointercancel","lostpointercapture","pointerleave"].forEach(type=>button.addEventListener(type,up));
 });
 $("mobileCollectButton").addEventListener("click",()=>{
   if(joined&&!quizOpen){socket.emit("collect");playBeep("tap");}
 });
 $("mobileFullscreenButton").addEventListener("click",async()=>{
   const ok=await requestGameFullscreen();
   if(!ok){$("connection").textContent="Mode layar penuh tidak didukung browser ini.";}
   else {$("connection").textContent="● Mode layar penuh";}
 });
}
bindVirtualJoystick();
document.addEventListener("fullscreenchange",()=>{
 document.body.classList.toggle("mobile-game-fullscreen",!!document.fullscreenElement);
});
window.addEventListener("blur",()=>{
 Object.keys(virtualInput).forEach(k=>virtualInput[k]=false);
 sendVirtualInput();
});

function updateDateTime(){
 const el=$("dateTime");
 if(!el)return;
 const now=new Date();
 const dateText=new Intl.DateTimeFormat("id-ID",{
   weekday:"long",day:"numeric",month:"long",year:"numeric"
 }).format(now);
 const timeText=new Intl.DateTimeFormat("id-ID",{
   hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false
 }).format(now);
 el.textContent=`${dateText} · ${timeText}`;
}
updateDateTime();
setInterval(updateDateTime,1000);

function setConnection(t){$("connection").textContent=t;}
socket.on("connect",()=>setConnection("● Terhubung ke server"));
socket.on("disconnect",()=>setConnection("○ Koneksi terputus, mencoba kembali..."));
socket.on("connect_error",()=>setConnection("○ Gagal terhubung"));
function renderHeroAnimals(){
  const hero=$("heroAnimals");
  if(!hero || hero.dataset.ready==="1")return;
  hero.dataset.ready="1";
  // Ten friendly animal heads, each with a staggered bounce animation.
  animalData.slice(0,10).forEach(([name,emoji],i)=>{
    const item=document.createElement("span");
    item.className="hero-animal";
    item.textContent=emoji;
    item.title=name;
    item.style.setProperty("--bounce-delay",`${i*0.11}s`);
    hero.appendChild(item);
  });
}
function renderPicker(){
  renderHeroAnimals();
  const usedNums=new Set((currentState?.players||[]).map(p=>p.number));
  // If another child took the currently highlighted number, release the local selection.
  if(selectedNumber!==null && usedNums.has(selectedNumber))selectedNumber=null;
  const grid=$("numberGrid");
  grid.innerHTML="";
  for(let n=1;n<=25;n++){
    const animal=animalData[n-1];
    const busy=usedNums.has(n);
    const selected=selectedNumber===n && !busy;
    const b=document.createElement("button");
    b.type="button";
    b.className="player-animal"+(selected?" selected":"")+(busy?" busy":"");
    b.disabled=busy;
    b.setAttribute("aria-label",`Nomor ${String(n).padStart(2,"0")}, ${animal[0]}${busy?", karakter sudah dipilih":""}`);
    b.innerHTML=`
      <span class="player-number">${String(n).padStart(2,"0")}</span>
      <span class="player-animal-emoji">${animal[1]}</span>
      <span class="player-animal-name">${animal[0]}</span>
      ${busy?'<span class="busy-message">KARAKTER SUDAH DIPILIH</span>':(selected?'<span class="selected-message">PILIHANMU</span>':'')}
    `;
    b.onclick=()=>{
      if(busy || joinPending)return;
      selectedNumber=n;
      selectedAnimal=n-1;
      $("joinError").textContent="";
      startSelectedGame();
    };
    grid.appendChild(b);
  }
  $("playButton").disabled=!(selectedNumber!==null);
}
renderHeroAnimals();
function startSelectedGame(){
 if(selectedNumber===null || joinPending)return;
 if(!socket.connected)return $("joinError").textContent="Server belum terhubung.";
 // Fullscreen must be requested directly from the character-selection tap/click.
 const fsTarget=document.documentElement;
 if(!document.fullscreenElement && fsTarget.requestFullscreen){
   const fsRequest=fsTarget.requestFullscreen({navigationUI:"hide"});
   if(fsRequest && fsRequest.catch)fsRequest.catch(()=>{});
 }
 joinPending=true;
 $("playButton").disabled=true;
 socket.emit("joinGame",{number:selectedNumber});
}
$("playButton").onclick=startSelectedGame;
socket.on("joinError",msg=>{
 joinPending=false;
 $("joinError").textContent=msg;
 $("playButton").disabled=!(selectedNumber!==null);
});
socket.on("joined",data=>{
 joinPending=false;
 joined=true;
 requestGameFullscreen();
 $("joinScreen").classList.add("hidden");
 $("gameScreen").classList.remove("hidden");
 $("myPlayer").textContent=`PEMAIN #${String(data.number).padStart(2,"0")} · ${animalData[data.animal][0]}`;
 startGame();
});
socket.on("worldState",state=>{
 currentState=state;
 if(!joined)renderPicker();
 updateHUD(state);
 if(sceneRef)setSceneState(sceneRef,state);
});
socket.on("playersState",players=>{
 if(!currentState)return;
 currentState.players=players;
 currentState.leaderboard=players.map(p=>({number:p.number,animal:p.animal,emoji:p.emoji,total:p.total,counts:p.counts}))
   .sort((a,b)=>b.total-a.total||a.number-b.number);
 if(sceneRef)setSceneState(sceneRef,currentState);
 updateHUD(currentState);
});
function updateHUD(s){
  if(!joined)return;
  const me=s.players.find(p=>p.id===socket.id);
  if(me){
    $("myCounts").innerHTML=categories.map(([k,label,emoji])=>`<div class="count-row"><span>${emoji} ${label}</span><b>${me.counts[k]||0}</b></div>`).join("");
    $("myTotal").textContent=me.total;
  }
  const totalsNow=new Map((s.players||[]).map(p=>[p.id,Number(p.total||0)]));
  let scoreIncreased=false;
  for(const [id,total] of totalsNow){
    const previous=previousPlayerTotals.get(id);
    if(previous!==undefined && total>previous){scoreIncreased=true;break;}
  }
  const board=document.getElementById("leaderboardCard");
  if(scoreIncreased && board){
    board.classList.remove("score-pulse");
    void board.offsetWidth;
    board.classList.add("score-pulse");
    window.setTimeout(()=>board.classList.remove("score-pulse"),700);
  }
  previousPlayerTotals=totalsNow;
  $("leaderboard").innerHTML=s.leaderboard.slice(0,25).map((p,i)=>`<div class="rank"><b>${i+1}.</b><span>${p.emoji} #${String(p.number).padStart(2,"0")}</span><strong>${p.total}</strong></div>`).join("")||"<small>Menunggu pemain...</small>";
}
function showFinalSummary(stats){
 const counts=stats?.counts||{};
 $("summaryPlayer").textContent=`Pemain ${String(stats?.number||selectedNumber||"").padStart(2,"0")} · ${animalData[stats?.animal??selectedAnimal??0]?.[0]||"Sahabat"}`;
 $("summaryCounts").innerHTML=categories.map(([key,label,emoji])=>
   `<div class="summary-count"><span>${emoji} ${label}</span><strong>${Number(counts[key]||0)}</strong></div>`
 ).join("");
 $("summaryTotal").textContent=Number(stats?.total||0);
 $("gameScreen").classList.add("hidden");
 $("joinScreen").classList.add("hidden");
 $("summaryScreen").classList.remove("hidden");
}
function stopCurrentGame(){
 if(!joined)return;
 const me=currentState?.players?.find(p=>p.id===socket.id);
 const stats=me?{
   number:me.number,animal:me.animal,
   counts:{...me.counts},total:me.total
 }:{number:selectedNumber,animal:selectedAnimal,counts:{},total:0};
 joined=false;
 Object.keys(virtualInput).forEach(k=>virtualInput[k]=false);
 if(quizOpen){closeQuiz();}
 // Release this player number on the server, but keep the final tally on this screen.
 socket.emit("leaveGame");
 showFinalSummary(stats);
}
$("stopGameButton").addEventListener("click",stopCurrentGame);
$("returnHomeButton").addEventListener("click",async()=>{
 $("summaryScreen").classList.add("hidden");
 if(document.fullscreenElement && document.exitFullscreen){
   try{await document.exitFullscreen();}catch(e){}
 }
 if(game){game.destroy(true);game=null;sceneRef=null;}
 selectedNumber=null;selectedAnimal=null;joined=false;
 $("joinError").textContent="";
 $("joinScreen").classList.remove("hidden");
 renderPicker();
});
function openQuiz(data){
 quizOpen=true;
 playBeep("question");
 $("quizItem").textContent=`${data.item?.icon||"🎁"} ${data.item?.name||"Benda"}`;
 $("quizA").textContent=data.a;
 $("quizB").textContent=data.b;
 $("quizAnswer").value="";
 $("quizAnswer").disabled=false;
 quizAnswerPending=false;
 if(quizAnswerTimer){clearTimeout(quizAnswerTimer);quizAnswerTimer=null;}
 $("quizFeedback").textContent="Ketik jawaban. Jawaban benar akan langsung terkunci.";
 $("quizFeedback").className="quiz-feedback";
 $("quizOverlay").classList.remove("hidden");
 Object.keys(virtualInput).forEach(k=>virtualInput[k]=false);
 if(sceneRef)socket.emit("input",{up:false,down:false,left:false,right:false});
 window.setTimeout(()=>$("quizAnswer").focus(),60);
}
function closeQuiz(){
 quizOpen=false;
 $("quizOverlay").classList.add("hidden");
 $("quizAnswer").value="";
 $("quizAnswer").disabled=false;
 quizAnswerPending=false;
 if(quizAnswerTimer){clearTimeout(quizAnswerTimer);quizAnswerTimer=null;}
}
function submitQuizAnswer(){
 if(!quizOpen||quizAnswerPending)return;
 const raw=$("quizAnswer").value;
 if(raw==="")return;
 const answer=Number(raw);
 if(!Number.isInteger(answer)||answer<0||answer>999)return;
 quizAnswerPending=true;
 $("quizAnswer").disabled=true;
 $("quizFeedback").textContent="Memeriksa jawaban...";
 socket.emit("submitQuizAnswer",{answer});
}
$("quizAnswer").addEventListener("input",()=>{
 if(!quizOpen||quizAnswerPending)return;
 if(quizAnswerTimer)clearTimeout(quizAnswerTimer);
 const raw=$("quizAnswer").value.trim();
 if(raw==="")return;
 if(!/^\d{1,3}$/.test(raw)){
   $("quizFeedback").textContent="Masukkan jawaban berupa angka.";
   $("quizFeedback").className="quiz-feedback incorrect";
   return;
 }
 // A short pause lets children finish typing answers such as 10.
 quizAnswerTimer=window.setTimeout(submitQuizAnswer,450);
});
$("quizForm").addEventListener("submit",event=>event.preventDefault());
socket.on("quizQuestion",openQuiz);
socket.on("quizAnswerResult",result=>{
 if(result.correct){
   playBeep("correct");
   $("quizFeedback").textContent=result.message||"Hebat! +1 poin";
   $("quizFeedback").className="quiz-feedback correct";
   $("quizAnswer").disabled=true;
   window.setTimeout(closeQuiz,350);
 }else{
   playBeep("wrong");
   $("quizFeedback").textContent="Jawaban kamu salah. Coba lagi!";
   $("quizFeedback").className="quiz-feedback incorrect";
   window.setTimeout(()=>{
     if(!quizOpen)return;
     $("quizAnswer").value="";
     $("quizAnswer").disabled=false;
     quizAnswerPending=false;
     $("quizAnswer").focus();
   },650);
 }
});
socket.on("collectResult",r=>{
 if(r.ok){$("myTotal").textContent=r.total;if(sceneRef&&r.item&&sceneRef.animateCollectedItem)sceneRef.animateCollectedItem(r.item);}
 else if(r.message){/* quiet feedback for young players */}
});
// Phaser scene helpers
function addWorldDecor(scene){
 const g=scene.add.graphics();
 g.fillStyle(0x9ce7ad,1);g.fillRect(0,0,1800,1200);
 // Paths through the four themed gardens
 g.fillStyle(0xe9d9a8,1);g.fillRoundedRect(100,545,1600,110,42);g.fillRoundedRect(845,90,110,1020,42);
 // soft grass tufts
 for(let i=0;i<180;i++){let x=30+(i*97)%1740,y=30+(i*173)%1140;g.fillStyle(i%2?0x82d998:0x78cf8d,.35);g.fillCircle(x,y,2);}
 const zones=[["KEBUN BUAH",100,80,360,300,0xffe7a8],["KEBUN SAYUR",1280,80,400,300,0xd5f2bb],["TAMAN TANAMAN",100,820,400,300,0xf7d9e8],["ALAT TULIS",1280,820,400,300,0xd8e9ff]];
 zones.forEach(([name,x,y,w,h,c])=>{g.fillStyle(c,.22);g.fillRoundedRect(x,y,w,h,26);g.lineStyle(3,0xffffff,.7);g.strokeRoundedRect(x,y,w,h,26);scene.add.text(x+16,y+12,name,{fontFamily:"Arial",fontSize:"19px",fontStyle:"bold",color:"#38664a",backgroundColor:"#ffffffcc",padding:{x:7,y:4}}).setDepth(2);});
 // decorative trees around edges, not blocking collectible zones
 for(let i=0;i<34;i++){let x=35+(i*211)%1730,y=(i%2?35:1160);let t=scene.add.text(x,y,"🌳",{fontSize:"31px"}).setOrigin(.5).setDepth(3);}
 scene.add.text(900,600,"DUNIA 25 SAHABAT",{fontSize:"25px",fontStyle:"bold",color:"#43865a",alpha:.25}).setOrigin(.5).setDepth(1);
}
function addPlayer(scene,p){
 const c=scene.add.container(p.x,p.y);
 const shadow=scene.add.ellipse(0,18,34,10,0x37664a,.20);
 const face=scene.add.text(0,0,p.emoji||"🐰",{
   fontFamily:"Arial, sans-serif",fontSize:"40px"
 }).setOrigin(.5);
 const badge=scene.add.text(0,-39,String(p.number).padStart(2,"0"),{
   fontFamily:"Arial, sans-serif",
   fontSize:"16px",
   fontStyle:"normal",
   ...getPlayerBadgeStyle(p.number),
   padding:{x:7,y:4},
   stroke:"#ffffff",
   strokeThickness:3
 }).setOrigin(.5);
 badge.setDepth(200);
 // Direction pointer: moves around the animal to show the active facing.
 // The animal image itself always stays upright.
 const directionMarker=scene.add.triangle(0,25,0,-7,7,7,-7,7,0x17633a,1)
   .setStrokeStyle(1,0xffffff,1);
 c.add([shadow,face,directionMarker,badge]);
 c.setDepth(100+p.y);
 c._face=face;c._badge=badge;c._shadow=shadow;
 c._directionMarker=directionMarker;
 c._direction="down";
 return c;
}
function setSceneState(scene,s){
 if(!s)return;
 if(!scene.itemSprites)scene.itemSprites=new Map();
 const visible=new Map(s.items.map(i=>[i.id,i]));
 for(const [id,obj] of scene.itemSprites){
   if(!visible.has(id)&&!obj._collecting){obj.destroy();scene.itemSprites.delete(id);}
 }
 for(const item of s.items){
   if(scene.itemSprites.has(item.id))continue;
   makeItemSprite(scene,item);
 }
 if(!scene.playerSprites)scene.playerSprites=new Map();
 const present=new Set(s.players.map(p=>p.id));
 for(const [id,obj] of scene.playerSprites){
   if(!present.has(id)){obj.destroy();scene.playerSprites.delete(id);}
 }
 for(const p of s.players){
   let obj=scene.playerSprites.get(p.id);
   if(!obj){obj=addPlayer(scene,p);scene.playerSprites.set(p.id,obj);}
   obj._targetX=p.x;obj._targetY=p.y;
   obj._face.setText(p.emoji||"🐰");
   obj._badge.setText(String(p.number).padStart(2,"0"));
   obj._badge.setStyle({
     fontFamily:"Arial, sans-serif",
     fontSize:"16px",
     fontStyle:"normal",
     ...getPlayerBadgeStyle(p.number),
     padding:{x:7,y:4},
     stroke:"#ffffff",
     strokeThickness:2
   });
   obj._badge.setPosition(0,-39);
   obj._moving=!!p.moving;
   // Keep animal art upright. Move the small pointer to the direction
   // received from the server instead of rotating the animal artwork.
   const markerByDirection={
     up:{x:0,y:-25,angle:0},
     right:{x:25,y:0,angle:Math.PI/2},
     down:{x:0,y:25,angle:Math.PI},
     left:{x:-25,y:0,angle:-Math.PI/2}
   };
   const marker=markerByDirection[p.direction]||markerByDirection.down;
   obj._directionMarker.setPosition(marker.x,marker.y);
   obj._directionMarker.setRotation(marker.angle);
   // Face left/right without turning the animal upside down.
   // Several side-view animal sprites (for example the duck) are drawn
   // facing left by default, so mirror them when moving right.
   // For up/down keep the animal upright and use the directional pointer.
   obj._face.setRotation(0);
   obj._face.setFlipX(p.direction==="right");
   obj._direction=p.direction;
 }
}
function makeItemSprite(scene,item){
   const iconText=(item.icon||"").trim();
   if(!iconText)return; // no icon means no object sprite and no fallback text
   const icon=scene.add.text(0,0,iconText,{
     fontFamily:"Arial, sans-serif",fontSize:"31px"
   }).setOrigin(.5);
   const c=scene.add.container(item.x,item.y,[icon]).setDepth(20+item.y);
   c._icon=icon;c._collecting=false;
   // Gentle bounce animation, without a circle or caption behind the item.
   scene.tweens.add({
     targets:c,y:item.y-6,duration:500,yoyo:true,repeat:-1,
     ease:"Sine.easeInOut",delay:Math.floor(Math.random()*300)
   });
   scene.itemSprites.set(item.id,c);
}
function animateCollectedItem(item){
   const obj=this.itemSprites&&this.itemSprites.get(item.id);
   if(!obj||obj._collecting)return;
   obj._collecting=true;

   const scene=this;
   const x=obj.x, y=obj.y;

   // Star burst: small stars fly outward from the collected object.
   const starCount=8;
   for(let i=0;i<starCount;i++){
     const angle=(Math.PI*2*i/starCount)-(Math.PI/2);
     const distance=34+(i%2)*9;
     const star=scene.add.star(x,y,5,3,8,0xffd447)
       .setStrokeStyle(1,0xffa51f,1)
       .setDepth(5000);
     scene.tweens.add({
       targets:star,
       x:x+Math.cos(angle)*distance,
       y:y+Math.sin(angle)*distance,
       alpha:0,
       scale:0.25,
       angle:90,
       duration:420,
       ease:"Cubic.easeOut",
       onComplete:()=>star.destroy()
     });
   }

   // Floating +1 feedback, easy for young children to notice.
   const plus=scene.add.text(x,y-22,"+1",{
     fontFamily:"Arial, sans-serif",
     fontSize:"25px",
     fontStyle:"bold",
     color:"#ffffff",
     stroke:"#168447",
     strokeThickness:5
   }).setOrigin(0.5).setDepth(5001);
   scene.tweens.add({
     targets:plus,
     y:y-78,
     alpha:0,
     scale:1.2,
     duration:650,
     ease:"Cubic.easeOut",
     onComplete:()=>plus.destroy()
   });

   // The collectible makes one clear hop, then disappears.
   scene.tweens.killTweensOf(obj);
   scene.tweens.add({
     targets:obj,
     y:y-72,
     scale:1.35,
     angle:12,
     alpha:0,
     duration:430,
     ease:"Back.easeIn",
     onComplete:()=>{
       obj.destroy();
       scene.itemSprites.delete(item.id);
     }
   });
}
function drawWorld(scene){addWorldDecor(scene);scene.cameras.main.setBounds(0,0,1800,1200);scene.cameras.main.setZoom(.92);}
function updateScene(scene,delta=16.67){
 if(!scene.playerSprites)return;
 scene.animateCollectedItem=animateCollectedItem;
 const me=scene.playerSprites.get(socket.id);
 if(me)scene.cameras.main.startFollow(me,true,.12,.12);
 for(const obj of scene.playerSprites.values()){
  if(obj._targetX!==undefined){
    // Time-based interpolation: smooths 20 Hz server snapshots without
    // making movement depend on the client's frame rate.
    const blend=1-Math.exp(-Math.max(1,delta)/55);
    obj.x=Phaser.Math.Linear(obj.x,obj._targetX,blend);
    obj.y=Phaser.Math.Linear(obj.y,obj._targetY,blend);
    obj.setDepth(100+obj.y);
    if(obj._moving){
      const bob=Math.sin(scene.time.now/75)*2.8;
      obj._face.y=bob;
      obj._shadow.setScale(1-Math.abs(bob)*.018,1);
    }else{
      obj._face.y=0;obj._shadow.setScale(1,1);
    }
  }
 }
}
function startGame(){
 if(game)return;
 const config={type:Phaser.AUTO,parent:"gameCanvas",width:1100,height:680,backgroundColor:"#c9f5d8",scale:{mode:Phaser.Scale.RESIZE,autoCenter:Phaser.Scale.CENTER_BOTH},scene:{
  create:function(){sceneRef=this;this.itemSprites=new Map();this.playerSprites=new Map();drawWorld(this);this.cursors=this.input.keyboard.createCursorKeys();this.space=this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);this.lastInput=0;this.lastCollect=0;setSceneState(this,currentState);},
  update:function(time,delta){
   if(!quizOpen){
     const input={
       up:this.cursors.up.isDown||virtualInput.up,
       down:this.cursors.down.isDown||virtualInput.down,
       left:this.cursors.left.isDown||virtualInput.left,
       right:this.cursors.right.isDown||virtualInput.right
     };
     if(time-this.lastInput>=50){socket.emit("input",input);this.lastInput=time;}
     if(Phaser.Input.Keyboard.JustDown(this.space)&&time-this.lastCollect>250){socket.emit("collect");this.lastCollect=time;}
   }
   updateScene(this,Number.isFinite(delta)?delta:16.67);
  }
 }};
 game=new Phaser.Game(config);
};
if(currentState)renderPicker();
