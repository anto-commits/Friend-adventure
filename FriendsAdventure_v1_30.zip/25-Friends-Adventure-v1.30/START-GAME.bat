@echo off
setlocal
cd /d "%~dp0"
title 25 Friends Adventure

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js belum terpasang.
  echo Silakan install Node.js versi LTS dari https://nodejs.org/
  echo Setelah selesai, tutup jendela ini dan jalankan START-GAME.bat lagi.
  pause
  exit /b 1
)

if not exist "node_modules\express\package.json" (
  echo.
  echo Memasang komponen game untuk pertama kali...
  echo Pastikan komputer server terhubung ke internet.
  call npm install
  if errorlevel 1 (
    echo.
    echo Instalasi gagal. Periksa koneksi internet lalu jalankan kembali.
    pause
    exit /b 1
  )
)

echo.
echo Menjalankan 25 Friends Adventure...
echo Alamat game akan ditampilkan oleh server di bawah ini.
echo Tekan Ctrl+C untuk menghentikan server.
echo.
call npm start
pause
