@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js belum terpasang. Install Node.js LTS dari https://nodejs.org/
 pause
 exit /b 1
)
call npm install
if errorlevel 1 (
 echo Instalasi gagal. Periksa koneksi internet.
) else (
 echo Instalasi selesai. Jalankan START-GAME.bat
)
pause
