25 FRIENDS ADVENTURE — VERSION 1.5
=====================================

PERBAIKAN PENTING
Error "Cannot find module 'express'" terjadi karena dependensi belum dipasang.
Versi ini menyediakan START-GAME.bat yang otomatis menjalankan npm install
pada penggunaan pertama (komputer server harus terhubung ke internet).

CARA MENJALANKAN DI WINDOWS (DISARANKAN)
1. Ekstrak seluruh ZIP ke satu folder, jangan menjalankan file dari dalam ZIP.
2. Pastikan Node.js versi LTS (18 atau lebih baru) sudah terpasang.
3. Klik dua kali START-GAME.bat.
4. Pada penggunaan pertama, tunggu proses pemasangan selesai.
5. Setelah muncul "25 Friends Adventure running on port 3000", buka:
   http://localhost:3000

CARA MANUAL
1. Buka CMD/PowerShell pada folder yang berisi package.json dan server.js.
2. Jalankan: npm install
3. Tunggu sampai selesai tanpa error.
4. Jalankan: npm start

PENTING: npm install harus dijalankan di folder project yang berisi package.json.
Jangan menjalankan npm start dari folder induk atau folder lain.

AKSES DARI KOMPUTER LAIN DI LAN
Buka http://IP-KOMPUTER-SERVER:3000
Pastikan firewall Windows mengizinkan Node.js / TCP port 3000.

DEPLOY ONLINE
Project ini memerlukan hosting Node.js yang mendukung WebSocket.
Unggah isi folder project ke layanan hosting Node.js, atur ADMIN_PIN,
deploy, lalu bagikan URL HTTPS hasil deploy kepada anak-anak.
Jangan memakai hosting file statis saja.

FITUR
- Maksimal 25 pemain dalam satu sesi.
- Nomor 01–25 menentukan karakter binatang secara otomatis.
- Satu map bersama.
- Kontrol panah dan SPACE untuk mengambil objek.
- 80 objek awal: 20 buah, 20 sayuran, 20 tanaman, 20 alat tulis.
- Objek yang diambil diganti setelah 2 detik di lokasi acak.
- Ikon objek tanpa lingkaran dan tanpa label.
- Karakter dan objek memakai animasi pantulan.
- Leaderboard real-time.
- Panel guru di /admin.

PANEL ADMIN
Buka http://localhost:3000/admin
PIN default: 2525.
Ganti PIN sebelum dipakai pada jaringan publik dengan environment variable ADMIN_PIN.

PEMERIKSAAN SERVER
Buka http://localhost:3000/health
Respons harus menunjukkan ok:true.

CATATAN KESTABILAN DAN PENGUJIAN
- Server mengatur posisi, pengambilan objek, dan skor; browser tidak menentukan skor.
- Posisi pemain dikirim terpisah dari data map agar lalu lintas jaringan lebih ringan.
- Data sesi saat ini berada di memori server. Jika server restart, sesi dan skor akan reset.
- Jika koneksi internet putus, pemain akan terputus dari server.
- Phaser dimuat dari CDN, sehingga browser perlu akses internet.
- Uji dahulu 2 komputer, kemudian 5, 10, dan 25 komputer.
- Tidak ada klaim bahwa beban 25 komputer fisik sudah diuji pada ZIP ini.


VERSION 1.6 — CHARACTER DIRECTION
- Move with the four arrow keys.
- A small pointer around the animal shows the current movement direction.
- The animal image remains upright and is never turned sideways or upside down.
- SPACE collects nearby objects.
- This release is based directly on v1.5.


VERSION 1.7 — CHARACTER FACING
- Left/right: animal artwork turns to face the direction by horizontal mirroring.
- Up/down: animal artwork remains upright; the direction pointer indicates up/down.
- No 90-degree or 180-degree rotation is applied to animal art.
- This release is based directly on v1.6.


VERSION 1.8 — PORT ALREADY IN USE FIX
Jika muncul error EADDRINUSE (port 3000 sedang dipakai):
- Versi ini otomatis mencoba port berikutnya, mulai 3001 sampai 3010.
- Lihat nomor port yang tertulis pada jendela START-GAME.bat.
- Semua komputer pemain harus membuka alamat IP server dengan nomor port yang sama.
  Contoh jika server menampilkan port 3001:
  http://192.168.x.x:3001
- Jangan menutup jendela server selama permainan berlangsung.
- Jika semua port 3000–3010 sedang dipakai, tutup server lama yang tidak digunakan.


VERSION 1.9 — SHOW REAL LAN IP
- START-GAME.bat now displays the actual LAN IPv4 address automatically.
- Use the line "Alamat IP untuk pemain" on every child computer.
- Example: http://192.168.3.149:3000
- localhost is only for opening the game on the server computer itself.


VERSION 1.10 — JOIN SCREEN VISUAL REVISION
- The top of the join screen displays 10 bouncing animal characters.
- Each player number and its automatically assigned animal are shown together in one card.
- A number already being used by a connected player is marked red with "KARAKTER SUDAH DIPILIH".
- Select one available card, then press the dark-red "MULAI BERMAIN" button.
- The button has a gentle bounce animation and becomes still/muted when no number is selected.


VERSION 1.11 — COLLECT EFFECT
- Move close to an object and press SPACE.
- The object hops upward and disappears.
- Eight small stars burst outward.
- A +1 label floats upward and fades.
- The server respawns a replacement object from the same category at a random location after 2 seconds.
- Collection is synchronized by the server; the same object cannot be collected twice.


VERSION 1.12 — PLAYER IDENTITY COLORS
- Each animal always displays its player number above its head.
- Each number 01–25 has its own consistent badge color.
- Badge text color automatically contrasts with the badge background.
- The same number uses the same color on every computer, making players easier to recognize.


VERSION 1.13 — PLAYER NUMBER LABEL
- The number above the animal no longer has a # symbol.
- The number is displayed in regular (not bold) font, slightly larger for clarity.
- The colored badge background remains the same.


VERSION 1.14 — MULTIPLAYER MOVEMENT SMOOTHING
- The server updates movement at 20 Hz (every 50 milliseconds).
- Player positions are broadcast separately at 20 Hz.
- Keyboard input is sent at 20 Hz.
- Clients interpolate between received positions to reduce choppy movement.
- The server remains the authority for player positions and collected objects.
- Full world state is not resent for every movement update.


VERSION 1.15 — BLACK CANVAS FIX
- Fixes a Phaser update-loop parameter issue that could stop the game scene and leave a black canvas.
- The scene now receives Phaser's frame delta correctly and uses a safe default if needed.
- Retains the 20 Hz multiplayer movement and interpolation improvements from v1.14.
- After updating, refresh the browser with Ctrl+F5.


VERSION 1.16 — STOP, COLLECTION SUMMARY AND FULLSCREEN
- Press BERHENTI BERMAIN during a session to finish your turn.
- A summary shows collected fruit, vegetables, plants, stationery and total items.
- The player slot is released after stopping.
- Press KEMBALI KE LAYAR UTAMA to return to player selection.
- MULAI BERMAIN requests fullscreen mode from the browser. Fullscreen availability depends
  on browser policy; the game can still run if fullscreen is denied.
- Returning to the main screen exits fullscreen when supported.


VERSION 1.18 — GAME INTERFACE
- Header shows Indonesian weekday, date, month, year and a live HH:MM:SS clock.
- Petunjuk are arranged vertically with each key symbol on the left and explanation on the right.
- Koleksiku remains in its own collection card.
- Papan Skor pulses briefly whenever an item increases any player's score.
- Scoreboard refreshes from compact player-state updates as well as full world-state updates.


VERSION 1.19 — ADDITION QUIZ
How to play:
1. Move close to an object with the arrow keys.
2. Press SPACE to open an addition question.
3. Type the answer (0–10) in the answer box.
4. Press ENTER or click the green ENTER button.
5. Correct answer awards +1 point and collects the item.
6. Wrong answer gives a gentle retry message; no point is awarded yet.
Question rules:
- Two positive whole numbers are generated randomly.
- The sum never exceeds 10.
- The server generates and checks the correct answer.
- An item is reserved while one child answers it, preventing duplicate collection.
- After a correct answer, the item replacement appears at a random position after 2 seconds.


VERSION 1.20 — MOBILE CONTROLS AND SOUND
- On phones/tablets, use the virtual directional joystick to move.
- Tap AMBIL when standing near an object to open the addition question (same function as SPACE).
- Use the LAYAR PENUH button for fullscreen where the browser supports the Fullscreen API.
- Short beeps play for opening a question, correct/incorrect answers, and control taps.
- On PC, continue using arrow keys, SPACE and ENTER.
- Mobile browser audio requires a user gesture; the first tap activates sound.
- Some mobile browsers (notably iOS Safari) may restrict webpage fullscreen. The game remains playable
  if fullscreen is unavailable.
