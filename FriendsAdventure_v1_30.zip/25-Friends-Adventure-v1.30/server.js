const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const os = require("os");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PREFERRED_PORT = Number(process.env.PORT || 3000);
const ADMIN_PIN = process.env.ADMIN_PIN || "2525";
const MAX_PLAYERS = 25;
const WORLD = { width: 1800, height: 1200 };
const animals = [
  ["Kelinci","🐰"],["Kucing","🐱"],["Panda","🐼"],["Beruang","🐻"],["Anak Ayam","🐥"],
  ["Gajah","🐘"],["Rubah","🦊"],["Katak","🐸"],["Singa","🦁"],["Harimau","🐯"],
  ["Monyet","🐵"],["Koala","🐨"],["Anjing","🐶"],["Penguin","🐧"],["Jerapah","🦒"],
  ["Kura-kura","🐢"],["Burung Hantu","🦉"],["Babi","🐷"],["Rusa","🦌"],["Unicorn","🦄"],
  ["Tupai","🐿️"],["Serigala","🐺"],["Kuda","🐴"],["Domba","🐑"],["Bebek","🦆"]
];
const categories = [
  {key:"buah", label:"Buah", folder:"buah", entries:[
    ["Apel","🍎"],["Pisang","🍌"],["Jeruk","🍊"],["Mangga","🥭"],["Anggur","🍇"],
    ["Stroberi","🍓"],["Semangka","🍉"],["Nanas","🍍"],["Pir","🍐"],["Pepaya","🧡"],
    ["Melon","🍈"],["Jambu biji","🍏"],["Buah naga","🐉"],["Rambutan","🍒"],["Salak","🥥"],
    ["Durian","🥝"],["Manggis","🟣"],["Sirsak","🍈"],["Duku","🟡"],["Belimbing","⭐"]
  ]},
  {key:"sayuran", label:"Sayuran", folder:"sayuran", entries:[
    ["Wortel","🥕"],["Tomat","🍅"],["Brokoli","🥦"],["Jagung","🌽"],["Terong","🍆"],
    ["Bayam","🥬"],["Timun","🥒"],["Kentang","🥔"],["Kubis","🥬"],["Labu","🎃"],
    ["Buncis","🫛"],["Kapri","🫛"],["Sawi","🥬"],["Selada","🥗"],["Paprika","🫑"],
    ["Bawang merah","🧅"],["Bawang putih","🧄"],["Daun bawang","🌱"],["Kembang kol","🥦"],["Jamur","🍄"]
  ]},
  {key:"tanaman", label:"Tanaman", folder:"tanaman", entries:[
    ["Bunga matahari","🌻"],["Mawar","🌹"],["Melati","🌼"],["Anggrek","🌺"],["Kaktus","🌵"],
    ["Bunga sepatu","🌺"],["Lavender","🪻"],["Tulip","🌷"],["Teratai","🪷"],["Peony","🌸"],
    ["Bougenville","💐"],["Hortensia","💠"],["Kenanga","🌼"],["Kamboja","🌸"],["Gardenia","🤍"],
    ["Monstera","🌿"],["Pakis","🌿"],["Bambu","🎋"],["Pohon kecil","🌳"],["Bibit tanaman","🌱"]
  ]},
  {key:"alat-tulis", label:"Alat tulis", folder:"alat-tulis", entries:[
    ["Pensil","✏️"],["Pulpen","🖊️"],["Penghapus","🧽"],["Penggaris","📏"],["Buku","📕"],
    ["Buku gambar","📘"],["Krayon","🖍️"],["Spidol","🖊️"],["Gunting","✂️"],["Lem","🧴"],
    ["Stapler","📎"],["Isolasi","🩹"],["Binder clip","🗜️"],["Paper clip","📎"],["Binder","📒"],
    ["Rautan","🔺"],["Sticky notes","🗒️"],["Kalkulator","🧮"],["Amplop","✉️"],["Folder","📁"]
  ]}
];
let players = new Map();
let items = [];
let gamePaused = false;
let gameStarted = true;
let gameEnded = false;


function makeItems() {
  const list = [];
  categories.forEach((cat, ci) => {
    cat.entries.forEach(([name, icon], i) => {
      // Four broad map zones, but objects remain in the same shared world.
      const zoneX = [260, 680, 1120, 1510][ci];
      const zoneY = [300, 850, 350, 850][ci];
      const x = zoneX + ((i % 5) - 2) * 62 + ((Math.floor(i/5)%2)*22);
      const y = zoneY + (Math.floor(i/5)-1.5) * 82 + ((i%3)-1)*12;
      list.push({
        id:`${cat.key}-${String(i+1).padStart(2,"0")}`,
        category:cat.key, label:cat.label, name, icon,
        x:Math.max(55,Math.min(WORLD.width-55,x)),
        y:Math.max(70,Math.min(WORLD.height-70,y)),
        collected:false
      });
    });
  });
  return list;
}
function randomItemPosition() {
  return { x:Math.round(90+Math.random()*(WORLD.width-180)), y:Math.round(110+Math.random()*(WORLD.height-220)) };
}
function spawnReplacement(categoryKey) {
  const cat=categories.find(c=>c.key===categoryKey);
  if(!cat)return;
  const [name,icon]=cat.entries[Math.floor(Math.random()*cat.entries.length)];
  const pos=randomItemPosition();
  const id=`${categoryKey}-respawn-${Date.now()}-${Math.floor(Math.random()*100000)}`;
  items.push({id,category:categoryKey,label:cat.label,name,icon,x:pos.x,y:pos.y,collected:false});
  broadcast();
}
function publicState() {
  return {
    players:[...players.values()].map(p=>({
      id:p.id, number:p.number, animal:p.animal, emoji:p.emoji,
      x:p.x, y:p.y, direction:p.direction, moving:p.moving,
      counts:p.counts, total:p.total
    })),
    items:items.filter(i=>!i.collected && !i.reservedBy),
    leaderboard:[...players.values()].map(p=>({
      number:p.number, animal:p.animal, emoji:p.emoji, total:p.total,
      counts:p.counts
    })).sort((a,b)=>b.total-a.total || a.number-b.number),
    paused:gamePaused, ended:gameEnded, started:gameStarted,
    world:WORLD, maxPlayers:MAX_PLAYERS
  };
}
function broadcast() { io.emit("worldState", publicState()); }
function numberInUse(n, exceptId=null) {
  for (const p of players.values()) if (p.number===n && p.id!==exceptId) return true;
  return false;
}
function animalInUse(a, exceptId=null) {
  for (const p of players.values()) if (p.animal===a && p.id!==exceptId) return true;
  return false;
}
app.use(express.static(path.join(__dirname,"public")));
app.get("/health", (_req,res)=>res.json({ok:true,players:players.size,itemsLeft:items.filter(i=>!i.collected).length}));
app.get("/admin", (_req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));

io.on("connection", socket => {
  socket.emit("worldState", publicState());

  socket.on("joinGame", data => {
    const n = Number(data?.number);
    // Fixed mapping: player number 01 gets animal 01, number 02 gets animal 02, etc.
    const a = n - 1;
    if (!Number.isInteger(n) || n<1 || n>25) return socket.emit("joinError","Pilih nomor 01 sampai 25.");
    if (players.size>=MAX_PLAYERS && !players.has(socket.id)) return socket.emit("joinError","Permainan sudah penuh.");
    if (numberInUse(n,socket.id)) return socket.emit("joinError","Nomor ini sedang digunakan pemain lain.");
    const old = players.get(socket.id);
    players.set(socket.id,{
      id:socket.id, number:n, animal:a, emoji:animals[a][1],
      x:old?.x ?? 900 + (Math.random()*100-50),
      y:old?.y ?? 600 + (Math.random()*100-50),
      direction:"down", moving:false, input:{up:false,down:false,left:false,right:false},
      counts:old?.counts ?? {buah:0,sayuran:0,tanaman:0,"alat-tulis":0},
      total:old?.total ?? 0
    });
    socket.emit("joined",{number:n,animal:a,animalName:animals[a][0]});
    broadcast();
  });

  socket.on("leaveGame", () => {
    const p=players.get(socket.id);
    if (!p) return;
    if (p.pendingQuiz) {
      const reserved=items.find(i=>i.id===p.pendingQuiz.itemId);
      if (reserved && reserved.reservedBy===socket.id) delete reserved.reservedBy;
    }
    players.delete(socket.id);
    broadcast();
  });

  socket.on("input", input => {
    const p=players.get(socket.id);
    if (!p || gamePaused || gameEnded) return;
    p.input={
      up:!!input?.up, down:!!input?.down,
      left:!!input?.left, right:!!input?.right
    };
  });

  socket.on("collect", () => {
    const p=players.get(socket.id);
    if (!p || gamePaused || gameEnded || p.pendingQuiz) return;
    let nearest=null, best=58;
    for (const item of items) {
      if (item.collected || (item.reservedBy && item.reservedBy!==socket.id)) continue;
      const d=Math.hypot(item.x-p.x,item.y-p.y);
      if (d<best) {best=d;nearest=item;}
    }
    if (!nearest) return socket.emit("collectResult",{ok:false,message:"Dekati benda lebih dekat."});

    // Reserve the object so two children cannot answer for the same item.
    nearest.reservedBy=socket.id;
    const a=1+Math.floor(Math.random()*9);
    const b=1+Math.floor(Math.random()*(10-a));
    p.pendingQuiz={itemId:nearest.id,a,b,answer:a+b,category:nearest.category};
    socket.emit("quizQuestion",{
      item:{id:nearest.id,name:nearest.name,icon:nearest.icon,label:nearest.label},
      a,b
    });
    broadcast();
  });

  socket.on("submitQuizAnswer", data => {
    const p=players.get(socket.id);
    if (!p || !p.pendingQuiz || gamePaused || gameEnded) return;
    const answer=Number(data?.answer);
    if (!Number.isInteger(answer) || answer<0 || answer>10) {
      return socket.emit("quizAnswerResult",{correct:false,message:"Masukkan angka 0 sampai 10."});
    }
    if (answer!==p.pendingQuiz.answer) {
      return socket.emit("quizAnswerResult",{correct:false,message:"Belum tepat. Coba hitung lagi, ya!"});
    }

    const pending=p.pendingQuiz;
    const item=items.find(i=>i.id===pending.itemId && !i.collected);
    if (!item || item.reservedBy!==socket.id) {
      p.pendingQuiz=null;
      return socket.emit("quizAnswerResult",{correct:false,message:"Benda sudah tidak tersedia. Coba benda lain."});
    }
    item.collected=true;
    delete item.reservedBy;
    p.pendingQuiz=null;
    p.counts[item.category]=(p.counts[item.category]||0)+1;
    p.total++;
    socket.emit("quizAnswerResult",{correct:true,message:"Hebat! Jawabanmu benar. +1 poin"});
    socket.emit("collectResult",{ok:true,category:item.category,total:p.total,
      item:{id:item.id,x:item.x,y:item.y,icon:item.icon,name:item.name}});
    broadcast();
    setTimeout(()=>{if(!gameEnded)spawnReplacement(item.category);},2000);
  });

  socket.on("cancelQuiz", () => {
    const p=players.get(socket.id);
    if (!p || !p.pendingQuiz) return;
    const item=items.find(i=>i.id===p.pendingQuiz.itemId);
    if (item && item.reservedBy===socket.id) delete item.reservedBy;
    p.pendingQuiz=null;
    broadcast();
  });

  socket.on("adminAction", data => {
    if (String(data?.pin||"")!==ADMIN_PIN) return socket.emit("adminResult",{ok:false,message:"PIN salah."});
    if (data.action==="pause") gamePaused=true;
    if (data.action==="resume") {gamePaused=false;gameEnded=false;}
    if (data.action==="end") {gameEnded=true;gamePaused=true;}
    if (data.action==="reset") {
      items=makeItems(); gamePaused=false; gameEnded=false;
      for (const p of players.values()) {
        p.counts={buah:0,sayuran:0,tanaman:0,"alat-tulis":0}; p.total=0;
        p.x=900; p.y=600;
      }
    }
    socket.emit("adminResult",{ok:true,message:"Perintah berhasil dijalankan."});
    broadcast();
  });

  socket.on("disconnect",()=>{
    const p=players.get(socket.id);
    if (p?.pendingQuiz) {
      const reserved=items.find(i=>i.id===p.pendingQuiz.itemId);
      if (reserved && reserved.reservedBy===socket.id) delete reserved.reservedBy;
    }
    players.delete(socket.id);broadcast();
  });
});

items=makeItems();
let lastPlayersBroadcast = 0;
setInterval(()=>{
  if (gamePaused || gameEnded) return;
  const now = Date.now();
  for (const p of players.values()) {
    const i=p.input, speed=4.8;
    let dx=(i.right?1:0)-(i.left?1:0);
    let dy=(i.down?1:0)-(i.up?1:0);
    if (dx && dy) {dx*=0.7071;dy*=0.7071;}
    p.x=Math.max(30,Math.min(WORLD.width-30,p.x+dx*speed));
    p.y=Math.max(50,Math.min(WORLD.height-50,p.y+dy*speed));
    p.moving=!!(dx||dy);
    if (Math.abs(dx)>Math.abs(dy) && dx) p.direction=dx>0?"right":"left";
    else if (dy) p.direction=dy>0?"down":"up";


  }
  // Server movement is processed on this 50 ms tick (20 Hz).
  // Send compact player-position updates at 20 Hz for smoother remote movement.
  // Full world state is still sent only on meaningful changes.
  if (players.size && now - lastPlayersBroadcast >= 50) {
    lastPlayersBroadcast = now;
    io.emit("playersState", [...players.values()].map(p=>({
      id:p.id, number:p.number, animal:p.animal, emoji:p.emoji,
      x:p.x, y:p.y, direction:p.direction, moving:p.moving,
      counts:p.counts, total:p.total
    })));
  }
},50);

// If port 3000 is already occupied (for example, an older game server is
// still running), try the next available port instead of crashing with
// EADDRINUSE. When PORT is explicitly set by a hosting provider, respect it.
function listenWithPortFallback(port) {
  const onError = (err) => {
    if (err.code === "EADDRINUSE" && !process.env.PORT && port < PREFERRED_PORT + 10) {
      console.log(`Port ${port} sedang dipakai. Mencoba port ${port + 1}...`);
      listenWithPortFallback(port + 1);
      return;
    }
    console.error(`Server gagal berjalan pada port ${port}:`, err.message);
    if (err.code === "EADDRINUSE") {
      console.error("Tutup server game lama atau tentukan PORT yang kosong.");
    }
    process.exitCode = 1;
  };
  server.once("error", onError);
  server.listen(port, () => {
    const actualPort = server.address().port;
    console.log("==========================================");
    console.log("25 FRIENDS ADVENTURE BERHASIL DIJALANKAN");
    console.log(`Alamat lokal komputer   : http://localhost:${actualPort}`);
    const lanAddresses = Object.values(os.networkInterfaces())
      .flat()
      .filter(info => info && info.family === "IPv4" && !info.internal)
      .map(info => info.address);
    if (lanAddresses.length) {
      lanAddresses.forEach((ip, index) => {
        console.log(`${index === 0 ? "Alamat IP untuk pemain" : "IP jaringan lainnya"} : http://${ip}:${actualPort}`);
      });
    } else {
      console.log(`Alamat IP untuk pemain : Tidak ditemukan otomatis; periksa IP komputer server.`);
    }
    console.log("Gunakan alamat IP di atas pada semua komputer pemain.");
    console.log("Tekan Ctrl+C untuk menghentikan server.");
    console.log("==========================================");
  });
}
listenWithPortFallback(PREFERRED_PORT);
